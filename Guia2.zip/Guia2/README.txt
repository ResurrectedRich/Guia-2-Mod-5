====================================================
  ACTIVIDAD INTEGRADORA 2 - MÓDULO 5 - GUÍA #2
  ENLACES EN PÁGINAS WEB
  Prof. Ramón Morillo Ullola
====================================================

ESTRUCTURA DE CARPETAS:
------------------------
Guia2_Enlaces/
│
├── Teoria/
│   └── Guia2_Enlaces.pdf       ← PARTE 2: Teoría + Autoevaluaciones resueltas
│
├── HTML/
│   ├── Ejemplos/               ← Ejemplos prácticos (págs. 26, 27, 29, 31)
│   │   ├── ejemplo_p26_tipos_enlaces.html
│   │   ├── ejemplo_p27_etiqueta_a.html
│   │   ├── ejemplo_p29_atributos.html
│   │   └── ejemplo_p31_recursos.html
│   │
│   ├── Actividades/            ← Actividades + Ejemplos guiados
│   │   ├── actividades_p26_28_30_32.html
│   │   ├── ejercicio_guiado_p40_41_listas.html
│   │   ├── ejemplo1_p42_seleccioninterna.html
│   │   └── ejemplo2_p43_enlaces_internos.html
│   │
│   ├── Laboratorio/            ← Mini laboratorio (págs. 23-24)
│   │   └── enlaces-laboratorio.html
│   │
│   ├── ProyectoUnidad3/        ← Proyecto Final Unidad 3 (págs. 32-33)
│   │   ├── index.html
│   │   ├── pagina2.html
│   │   └── contacto.html
│   │
│   ├── ProyectoIntegrador/     ← Proyecto Integrador (págs. 45-46)
│   │   └── historia_internet.html
│   │
│   └── MundoBicicleta/         ← Proyecto Mundo Bicicleta (págs. 47-48)
│       └── mundo_bicicleta.html
│
└── README.txt                  ← Este archivo

====================================================
CONTENIDO DEL PDF (Parte 2):
====================================================
- Síntesis teórica: Tipos de enlaces, etiqueta <a>,
  atributos, enlaces a recursos
- Autoevaluaciones resueltas:
  págs. 19, 21, 22 (Unidad 2)
  págs. 26, 28, 30, 32 (Unidad 3)

====================================================
CONTENIDO HTML (Parte 3):
====================================================
Todos los ejercicios prácticos de la guía:
- Ejemplos prácticos integrados
- Actividades de aprendizaje
- Mini laboratorio de enlaces
- Proyecto Final Unidad 3 (3 páginas interconectadas)
- Proyecto Integrador Historia de Internet
- Proyecto Mundo Bicicleta (proyecto integrador final)

====================================================
NOTA: Para ver los archivos HTML correctamente,
ábrelos con un navegador web (Chrome, Edge, Firefox)
o usa Live Server en Visual Studio Code.
====================================================
